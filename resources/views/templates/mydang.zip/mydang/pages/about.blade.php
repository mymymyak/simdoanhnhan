@extends($templateName.'.master')

@section('title', 'About')

@section('content')

    <div class="jumbotron">
        <h1>About Page</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa, molestiae, nam voluptatibus aspernatur consequuntur fuga totam minus vero aliquam quos eligendi cumque consectetur repellat minima ratione quae animi magni facere.</p>
    </div>

@stop